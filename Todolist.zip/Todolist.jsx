import React, { useState } from "react";
import TodoItem from "./ToDoItem";
import "./ToDoList.css";

const TodoList = () => {
  const [todos, setTodos] = useState([
    { id: 1, text: "Work on algorithms", completed: false },
    { id: 2, text: "Make a UI design", completed: false },
    { id: 3, text: "Create a new project", completed: false },
    { id: 4, text: "save the project", completed: true },
  ]);
  const [newTodo, setNewTodo] = useState("");

  const addTodo = () => {
    if (newTodo.trim() !== "") {
      setTodos([...todos, { id: Date.now(), text: newTodo, completed: false }]);
      setNewTodo("");
    }
  };

  const toggleComplete = (id) => {
    setTodos(
      todos.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  const editTodo = (id, newText) => {
    setTodos(
      todos.map((todo) => (todo.id === id ? { ...todo, text: newText } : todo))
    );
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter((todo) => todo.id !== id));
  };

  return (
    <div className="todo-container">
      <h2>Todo List App</h2>
      <div className="input-container">
        <input
          type="text"
          placeholder="Enter Todo"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
          className="todo-input"
        />
        <button className="add-btn" onClick={addTodo}>
          +
        </button>
      </div>
      {todos.map((todo) => (
        <TodoItem
          key={todo.id}
          todo={todo}
          toggleComplete={toggleComplete}
          editTodo={editTodo}
          deleteTodo={deleteTodo}
        />
      ))}
    </div>
  );
};

export default TodoList;
