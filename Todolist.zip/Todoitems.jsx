import React from "react";
import "./ToDoItem.css";
import { FaEdit } from "react-icons/fa";
import { MdDelete } from "react-icons/md";

const TodoItem = ({ todo, toggleComplete, editTodo, deleteTodo }) => {
  return (
    <div className="todo-item">
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() => toggleComplete(todo.id)}
        className="checkbox"
      />
      <span className={`todo-text ${todo.completed ? "completed" : ""}`}>
        {todo.text}
      </span>
      <button className="edit-btn" onclick={() => editTodo(todo.id)}>
        <FaEdit />
      </button>
      <button className="delete-btn" onclick={() => deleteTodo(todo.id)}>
        <MdDelete />
      </button>
    </div>
  );
};

export default TodoItem;
